#!/usr/bin/env python
# -*- coding: utf-8 -*-

__doc__ = """

  bloombox: CLI tool

"""

from bloombox import Bloombox; Bloombox(autorun=True)
