# -*- coding: utf-8 -*-

__doc__ = """

  bloombox: API clients for Python

"""
